package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Department;

@Repository
public interface DepartmentRepository extends JpaRepository<Department,Long> {

	Department findByDepartmentName(String dname);

//	Department save(Department department);
	//findAll
	//get all  the records
	//find by ID
	//get by ID
	//No need to add methods for predefined methods
	

}
