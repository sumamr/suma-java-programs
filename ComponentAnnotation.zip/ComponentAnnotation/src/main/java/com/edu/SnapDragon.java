package com.edu;

import org.springframework.stereotype.Component;

@Component
public class SnapDragon implements MobileProcessor{

	public void Processor() {
		System.out.println("Worlds Best Processor");
		
	}
	

}
